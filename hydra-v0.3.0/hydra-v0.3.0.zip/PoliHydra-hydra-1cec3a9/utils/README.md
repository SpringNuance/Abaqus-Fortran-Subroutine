# Utility scripts

## Contents

Various scripts for manipulating `.npz` files.

## Installation and running

The code requires Python 2.7 or Python 3 and
[NumPy](http://www.numpy.org) and [SciPy](http://www.scipy.org).

        $ pip install --upgrade numpy
        $ pip install --upgrade scipy

The scripts can be run without the need for installation.
